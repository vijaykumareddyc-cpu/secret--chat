# Secret Chat

A white-theme, anonymous-nickname, real-time private chat website built with Express, Socket.IO and PostgreSQL.

## Features
- No email, phone number, or real name required.
- Users claim a unique nickname; it stays reserved in the database.
- A private recovery token is saved in the current browser so the same person can return using that browser.
- Real-time one-to-one messages across devices.
- Message history is saved in PostgreSQL.
- Public nickname directory; private messages are delivered only to the two chat participants.
- Mobile-friendly layout.

## Important identity note
A nickname is reserved permanently in the database. A returning user needs the browser's saved recovery token to prove ownership. Clearing browser data or switching browsers/devices loses that local token. For multi-device recovery, you would need to add a recovery-code flow before launch. Do not claim a nickname that you may want someone else to use.

## Run locally
Requires Node.js 20+ and PostgreSQL.

1. Create a PostgreSQL database.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`.
3. In a terminal in this folder, run:
   ```bash
   npm install
   npm start
   ```
4. Open `http://localhost:3000`.

## Deploy online (Render + PostgreSQL)
This folder is ready to deploy as a Node web service, but it is not online until you deploy it under your own hosting account.

1. Create a PostgreSQL database with a provider such as Render.
2. Create a new Web Service from this folder or a Git repository containing it.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variable `DATABASE_URL` using the database's **internal connection URL** when the database and service are in the same provider/region.
6. Deploy. Open the URL provided by the host and test with two browsers/devices.

The service automatically creates its database tables at startup. Keep the database and its backups secure.

## Privacy and safety
This is an anonymous-nickname app, not end-to-end encrypted. The hosting operator and database administrator may technically access stored messages. Do not use it for passwords, financial details, or sensitive information. The public list reveals chosen nicknames. Add rate limits, abuse reporting/blocking, moderation, and a privacy policy before inviting the public at scale.
