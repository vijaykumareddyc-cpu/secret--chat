(() => {
  const socket = io();
  const $ = (id) => document.getElementById(id);
  const claimScreen = $("claim-screen");
  const chatScreen = $("chat-screen");
  const claimForm = $("claim-form");
  const nicknameInput = $("nickname");
  const claimError = $("claim-error");
  const usersList = $("users-list");
  const messagesEl = $("messages");
  const messageForm = $("message-form");
  const messageInput = $("message-input");
  const toastEl = $("toast");

  let myName = null;
  let activeName = null;
  let users = [];
  let knownMessageIds = new Set();
  let toastTimer = null;

  function showToast(text) {
    toastEl.textContent = text;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 3000);
  }
  function avatarText(name) {
    return (name || "?").trim().split(/\s+/).map(part => part[0]).join("").slice(0, 2).toUpperCase();
  }
  function timeText(date) {
    const d = new Date(date);
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  function make(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function enterChat(name) {
    myName = name;
    $("my-name").textContent = name;
    $("my-avatar").textContent = avatarText(name);
    claimScreen.classList.add("hidden");
    chatScreen.classList.remove("hidden");
    socket.emit("users:get");
  }
  function renderUsers() {
    const filter = $("search-users").value.trim().toLowerCase();
    const filtered = users.filter(name => name !== myName && name.toLowerCase().includes(filter));
    $("people-count").textContent = users.filter(name => name !== myName).length;
    usersList.replaceChildren();
    if (!filtered.length) {
      usersList.append(make("div", "no-users", filter ? "No nicknames match your search." : "No other nicknames yet. Share the site link so someone can join."));
      return;
    }
    filtered.forEach(name => {
      const row = make("button", `user-row${activeName === name ? " selected" : ""}`);
      row.type = "button";
      const avatar = make("div", "avatar", avatarText(name));
      const info = make("div", "user-info");
      info.append(make("strong", "", name), make("small", "", "Tap to chat"));
      row.append(avatar, info, make("span", "arrow", "›"));
      row.addEventListener("click", () => openChat(name));
      usersList.append(row);
    });
  }
  function addMessage(message) {
    if (!message || knownMessageIds.has(String(message.id))) return;
    knownMessageIds.add(String(message.id));
    const mine = message.sender === myName;
    const line = make("div", `message-line${mine ? " mine" : ""}`);
    const bubble = make("div", "bubble", message.body);
    const meta = make("div", "message-meta", `${mine ? "You" : message.sender} · ${timeText(message.createdAt)}`);
    line.append(bubble, meta);
    messagesEl.append(line);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
  function openChat(name) {
    if (!myName || !name || name === myName) return;
    activeName = name;
    knownMessageIds = new Set();
    messagesEl.replaceChildren();
    $("empty-chat").classList.add("hidden");
    $("active-chat").classList.remove("hidden");
    $("chat-name").textContent = name;
    $("chat-avatar").textContent = avatarText(name);
    renderUsers();
    socket.emit("chat:open", { with: name }, (result) => {
      if (!result || !result.ok) return showToast(result?.error || "Could not open chat.");
      if (activeName !== name) return;
      messagesEl.replaceChildren();
      knownMessageIds = new Set();
      if (!result.messages.length) {
        messagesEl.append(make("div", "day-divider", "This is the beginning of your conversation."));
      } else {
        result.messages.forEach(addMessage);
      }
      messagesEl.scrollTop = messagesEl.scrollHeight;
      messageInput.focus();
    });
  }

  claimForm.addEventListener("submit", (event) => {
    event.preventDefault();
    claimError.textContent = "";
    const nickname = nicknameInput.value.trim().replace(/\s+/g, " ");
    const savedName = localStorage.getItem("secretChatNickname");
    const savedToken = localStorage.getItem("secretChatToken");
    const token = savedName === nickname ? savedToken : null;
    socket.emit("identity:claim", { nickname, token }, (result) => {
      if (!result?.ok) {
        claimError.textContent = result?.error || "Could not join. Please try again.";
        return;
      }
      if (result.token) {
        localStorage.setItem("secretChatNickname", result.nickname);
        localStorage.setItem("secretChatToken", result.token);
      }
      enterChat(result.nickname);
    });
  });

  $("search-users").addEventListener("input", renderUsers);
  messageForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const body = messageInput.value.trim();
    if (!body || !activeName) return;
    messageInput.disabled = true;
    socket.emit("chat:send", { to: activeName, body }, (result) => {
      messageInput.disabled = false;
      if (!result?.ok) {
        showToast(result?.error || "Message could not be sent.");
        return;
      }
      messageInput.value = "";
      messageInput.focus();
    });
  });

  socket.on("users:list", (list) => {
    users = Array.isArray(list) ? list : [];
    renderUsers();
  });
  socket.on("chat:message", (payload) => {
    if (!payload?.message || !activeName) return;
    const m = payload.message;
    const isThisConversation =
      (m.sender === myName && m.recipient === activeName) ||
      (m.sender === activeName && m.recipient === myName);
    if (isThisConversation) addMessage(m);
  });
  socket.on("connect", () => {
    const savedName = localStorage.getItem("secretChatNickname");
    const savedToken = localStorage.getItem("secretChatToken");
    if (savedName && savedToken && !myName) {
      socket.emit("identity:claim", { nickname: savedName, token: savedToken }, (result) => {
        if (result?.ok) enterChat(result.nickname);
      });
    }
  });
  socket.on("connect_error", () => showToast("Connection problem. Refresh the page in a moment."));
})();
