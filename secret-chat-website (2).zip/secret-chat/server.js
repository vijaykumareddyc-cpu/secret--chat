const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");
const path = require("path");
const { Pool } = require("pg");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false } });
const PORT = process.env.PORT || 3000;

if (!process.env.DATABASE_URL) {
  console.error("Missing DATABASE_URL. Add a PostgreSQL database and set DATABASE_URL.");
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true }));

const hash = (value) => crypto.createHash("sha256").update(value).digest("hex");
const cleanNick = (value) => String(value || "").trim().replace(/\s+/g, " ").slice(0, 20);
const validNick = (value) => /^[\p{L}\p{N}_ -]{2,20}$/u.test(value);
const pairKey = (a, b) => [a, b].sort((x, y) => x.localeCompare(y)).join("::");

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      nickname TEXT PRIMARY KEY,
      token_hash TEXT NOT NULL UNIQUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS messages (
      id BIGSERIAL PRIMARY KEY,
      room_key TEXT NOT NULL,
      sender TEXT NOT NULL REFERENCES users(nickname),
      recipient TEXT NOT NULL REFERENCES users(nickname),
      body TEXT NOT NULL CHECK (char_length(body) <= 2000),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS messages_room_id_idx ON messages(room_key, id);
  `);
}

async function getUserByToken(token) {
  if (typeof token !== "string" || token.length < 20 || token.length > 200) return null;
  const result = await pool.query(
    "SELECT nickname FROM users WHERE token_hash = $1",
    [hash(token)]
  );
  return result.rows[0] || null;
}

async function getPublicUsers() {
  const result = await pool.query("SELECT nickname FROM users ORDER BY lower(nickname), nickname");
  return result.rows.map((row) => row.nickname);
}

async function broadcastUsers() {
  io.emit("users:list", await getPublicUsers());
}

io.on("connection", (socket) => {
  socket.data.nickname = null;

  socket.on("identity:claim", async (payload, callback) => {
    const reply = (data) => { if (typeof callback === "function") callback(data); };
    try {
      const nickname = cleanNick(payload && payload.nickname);
      const token = payload && payload.token;

      if (!validNick(nickname)) {
        return reply({ ok: false, error: "Use 2–20 characters: letters, numbers, spaces, _ or -." });
      }

      // A returning browser must prove possession of its secret token.
      if (typeof token === "string" && token.length >= 20) {
        const existing = await getUserByToken(token);
        if (existing) {
          if (existing.nickname !== nickname) {
            return reply({ ok: false, error: "This recovery key belongs to a different nickname." });
          }
          socket.data.nickname = existing.nickname;
          socket.join(`user:${existing.nickname}`);
          reply({ ok: true, nickname: existing.nickname, returning: true });
          await broadcastUsers();
          return;
        }
      }

      const newToken = crypto.randomBytes(32).toString("hex");
      try {
        await pool.query(
          "INSERT INTO users (nickname, token_hash) VALUES ($1, $2)",
          [nickname, hash(newToken)]
        );
      } catch (error) {
        if (error.code === "23505") {
          return reply({ ok: false, error: "That nickname is already claimed. Choose another, or use your saved recovery key." });
        }
        throw error;
      }

      socket.data.nickname = nickname;
      socket.join(`user:${nickname}`);
      reply({ ok: true, nickname, token: newToken, returning: false });
      await broadcastUsers();
    } catch (error) {
      console.error("identity:claim", error);
      reply({ ok: false, error: "Server error. Please try again." });
    }
  });

  socket.on("users:get", async () => {
    try { socket.emit("users:list", await getPublicUsers()); }
    catch (e) { console.error(e); }
  });

  socket.on("chat:open", async (payload, callback) => {
    const reply = (data) => { if (typeof callback === "function") callback(data); };
    try {
      const me = socket.data.nickname;
      const other = cleanNick(payload && payload.with);
      if (!me) return reply({ ok: false, error: "Choose your nickname first." });
      if (!other || other === me) return reply({ ok: false, error: "Choose another user." });

      const exists = await pool.query("SELECT nickname FROM users WHERE nickname = $1", [other]);
      if (!exists.rowCount) return reply({ ok: false, error: "That user does not exist." });

      const room = pairKey(me, other);
      socket.join(`chat:${room}`);
      const result = await pool.query(
        `SELECT id, sender, recipient, body, created_at
         FROM messages WHERE room_key = $1 ORDER BY id DESC LIMIT 100`,
        [room]
      );
      const messages = result.rows.reverse().map((m) => ({
        id: m.id, sender: m.sender, recipient: m.recipient,
        body: m.body, createdAt: m.created_at
      }));
      reply({ ok: true, with: other, messages });
    } catch (error) {
      console.error("chat:open", error);
      reply({ ok: false, error: "Could not open this chat. Please try again." });
    }
  });

  socket.on("chat:send", async (payload, callback) => {
    const reply = (data) => { if (typeof callback === "function") callback(data); };
    try {
      const sender = socket.data.nickname;
      const recipient = cleanNick(payload && payload.to);
      const body = String(payload && payload.body || "").trim();
      if (!sender) return reply({ ok: false, error: "Choose your nickname first." });
      if (!recipient || recipient === sender) return reply({ ok: false, error: "Invalid recipient." });
      if (!body || body.length > 2000) return reply({ ok: false, error: "Message must be 1–2000 characters." });

      const exists = await pool.query("SELECT nickname FROM users WHERE nickname = $1", [recipient]);
      if (!exists.rowCount) return reply({ ok: false, error: "That user does not exist." });

      const room = pairKey(sender, recipient);
      const inserted = await pool.query(
        `INSERT INTO messages (room_key, sender, recipient, body)
         VALUES ($1, $2, $3, $4)
         RETURNING id, sender, recipient, body, created_at`,
        [room, sender, recipient, body]
      );
      const m = inserted.rows[0];
      const message = {
        id: m.id, sender: m.sender, recipient: m.recipient,
        body: m.body, createdAt: m.created_at
      };
      // Deliver only to the two participants' private room, never to all users.
      io.to(`user:${sender}`).to(`user:${recipient}`).emit("chat:message", { room, message });
      reply({ ok: true, message });
    } catch (error) {
      console.error("chat:send", error);
      reply({ ok: false, error: "Message could not be sent. Please try again." });
    }
  });

  socket.on("disconnect", () => {
    // User accounts and messages remain saved in the database.
  });
});

initDb().then(() => {
  server.listen(PORT, () => console.log(`Secret Chat listening on port ${PORT}`));
}).catch((error) => {
  console.error("Could not initialize database:", error);
  process.exit(1);
});
